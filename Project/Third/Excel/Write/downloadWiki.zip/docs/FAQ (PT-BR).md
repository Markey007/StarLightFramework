## FAQ
**Quais são os requerimentos necessário para a biblioteca?**
* .Net Framework 3.5 ou superior. Esta biblioteca utiliza o System.IO.Packaging namespace.
**Quais são as funcionalidades suportadas na versão 2.9.0.1**
* Acesso das células através de intervalos (values, formulas, Formula R1C1...)
* Estilo da Célula (Formatação numérica, Fonte, Preenchimento, Bordas, Alinhamentos e outros)
* Mesclagem de células
* Names ranges
* Conteúdo da célula em Richtext
* Comentários
* Imagens
* Formas
* Gráficos (Exceto os gráficos: Bubble-, Radar-, Stock- e Surface)
* Hyperlinks
* Propriedades do Workbook 
* Cabeçalhos & Rodapés
* Opções de Impressão (como margem, orientação, tamanho de papel, area de impressão)
* Panéis Fixos
* Agrupar células
* Encriptação (AES128, 192 & 256).	
* Proteção de Workbook
* Proteção de Worksheet 
* Tabelas (build in styles)
* Coleção de células implementando Enumeration. Isto torna possível utiliza queries Linq.
* Array formulas
* Tabelas Pivot
* Validação de Dados

**O que NÃO é suportado pela biblioteca (estas são as features mais evidentes)?**
* Formatação Condicional
* Estilo - Preenchimento com gradiente e sombreamento
* Desenho de objetos
	* Linhas, smart art
	* Gráficos Bubble-, Radar-, Stock- e Surface.
	* Objectos Embutidos
* manipulação de links externos (você pode referenciar uma workbook externa utilizando fórmulas)
* Temas
* Imagens de Fundo
* Chart & Macro worksheets 	
* VBA
* Formulários & Controles ActiveX 

**Como eu instalo essa biblioteca**
Descompacte o pacote e copie o EPPlus.dll para um diretório de sua escolha, então simplesmente adicione a referência ao seu projeto.

**Como eu começo?**
Faça o download do projeto de exemplo e execute os diversos exemplos de aplicação console. Os exemplos mostram a maioria das coisas que podemos fazer. Existe também um simples exemplo web mostrando diferentes formas para enviar seu workbook gerado para o cliente.
O projeto de exemplo foi criado no Visual Studio 2010.

**Como eu referencio um intervalo de células?**
Funciona de forma muita parecida como no Excel. Aqui alguns exemplos...
{code:c#}
worksheet.Cells["A1"](_A1_).Value = 1; //Setar o valor da célula A1 para 1
worksheet.Cells[1,1](1,1).Value = 1;   //Setar o valor da célula A1 para 1

worksheet.Cells["A1:B3"](_A1_B3_).Style.NumberFormat.Format = "#,##0"; //Seta formatação numérica para o intervalo
worksheet.Cells[1,1,3,2](1,1,3,2).Style.NumberFormat.Format = "#,##0"; //O mesmo que acima,A1:B3

worksheet.Cells["A1:B3,D1:E57"](_A1_B3,D1_E57_).Style.NumberFormat.Format = "#,##0"; //Seta a formatação numérica para um intervalo contendo dois endereços.
worksheet.Cells["A:B"](_A_B_).Style.Font.Bold = true; //Seta negrito para as colunas A & B
worksheet.Cells["1:1,A:A,C3"](_1_1,A_A,C3_).Style.Font.Bold = true; //Seta negrito para linha 1,coluna A e célula C3
worksheet.Cells["A:XFD"](_A_XFD_).Style.Font.Name = "Arial"; //Seta fonte para Arial para todas as células da planilha
 
//Seta a cor de fundo para o intervalo selecionado (default é A1).
//O intervalo é selecionado utilizando o método worksheet.Select
worksheet.Cells.Style.Fill.PatternType = ExcelFillStyle.Solid;
worksheet.Cells.Style.Fill.BackgroundColor.SetColor(Color.LightGreen);	
{code:c#}

**Minha formatação numérica não funciona**
Se você adicionar dados numéricos como strings (como o original ExcelPackage faz), Excel irá tratar o dado como string e não será formatado. Não utilize o método ToString quando setar valores numéricos.
{code:c#}
string s="1000"
int i=1000;
worksheet.Cells["A1"](_A1_).Value=s; //Não será formatado
worksheet.Cells["A2"](_A2_).Value=i; //Será formatado
worksheet.Cells["A1:A2"](_A1_A2_).Style.NumberFormat.Format="#,##0";
{code:c#}

**Estou obtendo o erro que Excel encontrou conteudo ilegível quando abro meu documento gerado?**
Verifique suas fórmulas e formatações numéricas. As fórmulas e formatações numéricas não são validadas pela biblioteca, então se você digitar alguma coisa errada o pacote estará comrrompido. Utiliza os nomes das fórmulas em inglês. Os parâmetros das fórmulas são separados por vírgulas (,), parâmetros strings utilizam aspas duplas (").
{code:c#}
worksheet.Cells["A1"](_A1_).Formula="CONCATENATE(\"string1_\",\"test\")";
{code:c#}

Formatação numérica:
Utilize padrão internacional: ponto (.) para decimais, vírgula (milhares).
A forma mais fácil para verificar um formato ou fórmula é criar um Arquivo do Excel --> Faça a formatação / Adicione as fórmulas --> Salve-o como XLSX ---> Renomeio o arquivo para *.zip. Extraia o arquivo e olhe a formatação numérica no arquivo \xl\styles.xml e as fórmulas no arquivo \xl\worksheets\sheet#.xml.

**Eu não sei qual código de formatação númerica utilizar**
Faça o mesmo procedimento acima e olhe os formatos no arquivo styles.xml

**Eu tenho muitos dados que desejo carregar. O que eu devo fazer para obter melhor perfomance?**
Se você tem mais do que, vamos dizer, 5 000 células na sua planilha e está enfrentando problemas de perfomance, tenha isto em mente...
Sempre carregue as células do topo para baixo, esquerda para direita. Isto significa que se você quiser adicionar uma fórmula nos dados carregados, será mais rápido adicionar para todas as linhas do que carregar cada linha e depois selecionar o intervalo que você quer e adicionar a fórmula( ex. isto levará um bom tempo Worksheet.Cells["C1:C100000"](_C1_C100000_).Formula="A1+B1" ).
Se você deseja utilizar uma fórmula compartilhada, como no exemplo, tenha certeza que você criou as células em sequência ( use algo do tipo worksheet.Cells[row,forumlaColumn](row,forumlaColumn).Value=null para criar a célula). Então você pode adicionar a fórmula depois de ter carregado os dados.
Evite utilizar os métodos InsertRow e DeleteRow.

**Como eu adiciono um gráfico na minha planilha?**
Use a coleção drawings...
{code:c#}
var chart = sheet.Drawings.AddChart("chart1", eChartType.AreaStacked);
//Setar posição e tamanho
chart.SetPosition(0, 630);
chart.SetSize(800, 600);
//Adicionar uma série 
var serie = chart.Series.Add(Worksheet.Cells["A1:A4"](_A1_A4_),Worksheet.Cells["B1:B4"](_B1_B4_));
{code:c#}


**Como eu adiciono uma série de um tipo diferente no meu gráfico?**
Você deve fazer isso...
{code:c#}
ExcelChart chart = worksheet.Drawings.AddChart("chtLine", eChartType.LineMarkers);        
var serie1= chart.Series.Add(Worksheet.Cells["B1:B4"](_B1_B4_),Worksheet.Cells["A1:A4"](_A1_A4_));
//Agora para o segundo tipo de gráfico nós usaremos a coleção chart.PlotArea.ChartTypes...
var chartType2 = chart.PlotArea.ChartTypes.Add(eChartType.ColumnClustered);
var serie2 = chartType2.Series.Add(Worksheet.Cells["C1:C4"](_C1_C4_),Worksheet.Cells["A1:A4"](_A1_A4_));
{code:c#}

**Como eu adiciono um eixo secundário no meu gráfico?**
Se você deseja ter um eixo secundário no seu gráfico você precisa adicionar um novo charttype no gráfico.
Alguma coisa tipo isso...
{code:c#}
ExcelChart chart = worksheet.Drawings.AddChart("chtLine", eChartType.LineMarkers);        
var serie1= chart.Series.Add(Worksheet.Cells["B1:B4"](_B1_B4_),Worksheet.Cells["A1:A4"](_A1_A4_));
var chartType2 = chart.PlotArea.ChartTypes.Add(eChartType.LineMarkers);
var serie2 = chartSerie2.Series.Add(Worksheet.Cells["C1:C4"](_C1_C4_),Worksheet.Cells["A1:A4"](_A1_A4_));
chartType2.UseSecondaryAxis = true;

// Por default o eixo secundário X está invisível. Se você deseja exibí-lo, tente isso...
chartType2.XAxis.Deleted = false;
chartType2.XAxis.TickLabelPosition = eTickLabelPosition.High;
{code:c#}

**Consigo utilizar essa biblioteca com o Mono**
Boa pergunta! Eu ainda não tentei, então não tenho ideia. Por favor me de algum feedback caso você tenha tentado.

**Ehh, GPL?**
Sim, este projeto originou-se do projeto ExcelPackage que é licença GPL.
Isto significa que até eu ter absoluta certeza que eu reescrevi tudo, continuará em GPL.